package com.tslp.dca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TslpTrack4SpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TslpTrack4SpringbootApplication.class, args);
	}

}
