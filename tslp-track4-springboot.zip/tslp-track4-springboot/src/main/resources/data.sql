INSERT INTO CATEGORY (categoryName) VALUES
  ('Fashion'),
  ('Electronics'),
  ('Books'),
  ('Groceries'),
  ('Medicines');
  
INSERT INTO ROLE (role) VALUES
  ('CONSUMER'),
  ('SELLER');
  
INSERT INTO USER (username, password) VALUES
  ('jack','pass_word'),
  ('bob','pass_word'),
  ('apple','pass_word'),
  ('glaxo','pass_word');

INSERT INTO CART (totalAmount ,userId) VALUES
  (20,1),
  (0,2);

INSERT INTO USERROLE (userId, role) VALUES
  (1,1),
  (2,1),
  (3,2),
  (4,2);

INSERT INTO PRODUCT (price, productName, categoryId, sellerId) VALUES
  (29190, 'Apple iPad 10.2 8th Gen Wifi iOS Tablet', 2, 3),
  (10, 'Crocin pain relief tablet', 5, 4);

INSERT INTO CARTPRODUCT (cartId, productId, quantity) VALUES
  (1, 2, 2);





